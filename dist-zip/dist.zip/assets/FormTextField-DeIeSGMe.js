import{j as e}from"./react-C-yax-zd.js";import{h as r}from"./@mui-Cg5JgIJd.js";const o=t=>e.jsx(r,{variant:"outlined",size:"small",fullWidth:!0,...t,children:t.children});export{o as F};
