import{r}from"./react-C-yax-zd.js";var a=r.useLayoutEffect;export{a as i};
