const o=(i,{userTyping:t,input:n})=>{if(t)return n;const m={minimumFractionDigits:2,maximumFractionDigits:2};return Number(i).toLocaleString("en",m)};export{o as n};
